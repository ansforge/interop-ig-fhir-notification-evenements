# Glossaire - Notification d'Événements v3.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Autres Ressources**](autres_ressources.md)
* **Glossaire**

## Glossaire

| | |
| :--- | :--- |
| API | Application Programming Interface |
| ANS | Agence du Numérique en Santé |
| CI-SIS | Cadre d’Interopérabilité des SI de Santé |
| FHIR | Fast Healthcare Interoperability Resources |
| HL7 | Health Level 7 |

