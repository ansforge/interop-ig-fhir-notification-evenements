# Acronymes - ANS IG Example v0.1.0

* [**Table of Contents**](toc.md)
* [**Autres Ressources**](autres_ressources.md)
* **Acronymes**

## Acronymes

| | |
| :--- | :--- |
| API | Application Programming Interface |
| ANS | Agence du Numérique en Santé |
| CI-SIS | Cadre d’Interopérabilité des SI de Santé |
| FHIR | Fast Healthcare Interoperability Resources |
| HL7 | Health Level 7 |

