# Accueil - ANS IG Example v0.1.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/[code]/ImplementationGuide/ans.fhir.fr.[code] | *Version*:0.1.0 |
| Draft as of 2025-12-16 | *Computable Name*:ExampleIG |

 **Brief description of this Implementation Guide**
 [Add a brief description of this IG in English] 

> Cet Implementation Guide n'est pas la version courante, il s'agit de la version en intégration continue soumise à des changements fréquents uniquement destinée à suivre les travaux en cours. La version courante sera accessible via l'URL canonique suite à la première release : http://interop.esante.gouv.fr/ig/fhir/[code - ig]

### Introduction

Définir ici de quoi parle l'IG (En termes non expert, compréhensible par un patient). Rajouter également les détails techniques sur le contexte et le besoin de cet IG

Les principales sections de l'IG sont :

* Le contexte de l'IG, quelle problématique il résout
* Ce que les Implémenteurs doivent mettre en place
* Un onglet "Ressources de conformité" pour s'assurer d'un schéma global entre tous les IGs

### Périmètre du projet

Définir en quelques lignes en anglais quel est le périmètre du projet

Toujours laisser l'onglet "Ressources de conformité" pour s'assurer d'une cohérence globales entre tous les IGs

### Auteurs et contributeurs

| | | | |
| :--- | :--- | :--- | :--- |
| **Primary Editor** | Prenom Nom | Agence du Numérique en Santé | prenom.nom@address.email |

### Dépendances







### Propriété intellectuelle

Certaines ressources sémantiques de ce guide sont protégées par des droits de propriété intellectuelle couverte par les déclarations ci-dessous. L’utilisation de ces ressources est soumise à l’acceptation et au respect des conditions précisées dans la licence d’utilisation de chacune d’entre elle.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [CompetenceCS](CodeSystem-competence-code-system.md), [ExampleIG](index.md)...Show 22 more,[EyeColorVS](ValueSet-EyeColorVS.md),[MeltingPotVS](ValueSet-MeltingPotVS.md),[ModifiedAdministrativeGender](ValueSet-ModifiedAdministrativeGender.md),[NdE_CommunicationRequest_EventType](SearchParameter-NdE-CommunicationRequest-EventType.md),[NdE_Declarant](StructureDefinition-declarant.md),[NdE_Emetteur](CapabilityStatement-NdE-Emetteur.md),[NdE_EventDeclarationNdE](StructureDefinition-nde-eventdeclaration.md),[NdE_EventEmissionTime](StructureDefinition-event-emission-time.md),[NdE_EventTime](StructureDefinition-event-time.md),[NdE_EventType](StructureDefinition-event-type.md),[NdE_GestionnaireDAbonnements](CapabilityStatement-NdE-GestionnaireDAbonnements.md),[NdE_GestionnaireDeNotifications](CapabilityStatement-NdE-GestionnaireDeNotifications.md),[NdE_NotificationRequestNdE](StructureDefinition-nde-notificationrequest.md),[NdE_RecipientEndpoint](StructureDefinition-recipient-endpoint.md),[NdE_Souscripteur](CapabilityStatement-NdE-Souscripteur.md),[NdE_Start](StructureDefinition-start.md),[NdE_Subject](StructureDefinition-subject.md),[NdE_Subscriber](StructureDefinition-subscriber.md),[NdE_SubscriptionDate](StructureDefinition-subscription-date.md),[NdE_SubscriptionNdE](StructureDefinition-nde-subscription.md),[TypeCarteCS](CodeSystem-type-carte-code-system.md)and[TypeCarteVS](ValueSet-TypeCarteVS.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](https://interop.esante.gouv.fr/terminologies/1.4.0/CodeSystem-900000000000207008-20251001.html): [EyeColorVS](ValueSet-EyeColorVS.md) and [MeltingPotVS](ValueSet-MeltingPotVS.md)


