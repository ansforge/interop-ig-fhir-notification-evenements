# Accueil - Notification d'Événements v3.0.0-ballot

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/nde/ImplementationGuide/ans.fhir.fr.nde | *Version*:3.0.0-ballot |
| Draft as of 2026-03-13 | *Computable Name*:NDE |

 **Brief description of this Implementation Guide**
 This Implementation Guide defines the functional and technical scope for implementing event notification mechanisms within the French CI-SIS interoperability framework. It covers subscription management, event declaration, and notification order transmission using HL7 FHIR R4 resources and profiles.

>  **Attention !** 
 Cet Implementation Guide est actuellement en concertation. La version courante est accessible à l'adresse : https://interop.esante.gouv.fr/ig/fhir/nde 

### Introduction

Ce guide d'implémentation (IG) décrit un mécanisme de notification d’évènements permettant d’informer automatiquement une personne lorsqu’un évènement survient au cours de sa prise en charge.

Il s'agit par exemple, de recevoir une information lorsqu’un document est disponible, lorsqu’une hospitalisation débute ou se termine, ou lorsqu’une information significative est ajoutée à un dossier. Ces notifications peuvent concerner un patient ou un usager, un professionnel de santé, ou toute autre personne autorisée.

Sur le plan technique, cet IG s’inscrit dans le cadre du Cadre d’Interopérabilité des Systèmes d’Information de Santé (CI-SIS) et couvre les domaines sanitaire, médico-administratif, médico-social et social.
 Elle formalise les mécanismes nécessaires à :

* la gestion des abonnements à des types d’évènements,
* la déclaration d’évènements par des systèmes émetteurs,
* la transmission d’ordres de notification vers les abonnés concernés.

### Périmètre du projet

Cet IG définit le périmètre fonctionnel et technique de la mise en œuvre des mécanismes de notification d’évènements dans le cadre du CI-SIS.

Elle couvre la gestion des abonnements aux notifications, la déclaration des évènements et la transmission des ordres de notification, en s’appuyant sur des ressources et profils HL7 FHIR R4.

#### Lectorat cible

Ce document s’adresse aux développeurs des interfaces interopérables des systèmes implémentant le cas d’usage « Notification d’évènements » ou à toute autre personne intervenant dans le processus de mise en place de ces interfaces.

#### Ressources FHIR profilées

Les ressources profilées dans cet IG sont les suivantes :

| | | |
| :--- | :--- | :--- |
| Ressource FHIR | Profil | Description |
| [CommunicationRequest](CommunicationRequest) | [NdE_EventDeclarationNdE](StructureDefinition-nde-eventdeclaration.md) | EmissionEvenement contient les informations nécessaires pour transmettre un évènement à un système d’information ou à un composant d’un système d’information (gestionnaire d’évènements). Un évènement peut être un dépôt de documents, une sortie d’hôpital, etc. |
| [CommunicationRequest](CommunicationRequest) | [NdE_NotificationRequestNdE](StructureDefinition-nde-notificationrequest.md) | Ressource CommunicationRequest utilisée dans le Flux 4 - TransmissionOrdreNotification |
| [Subscription](Subscription) | [NdE_SubscriptionNdE](StructureDefinition-nde-subscription.md) | SouscriptionAbonnement concerne la création ou la mise à jour d’un abonnement. Un abonnement porte sur les types d'évènements qui intéressent l’abonné et qui peuvent faire l’objet d’une notification. Il est défini par l’identification de l’abonné, le média de notification à utiliser, la personne prise en charge associée aux évènements, le type d’événement donnant lieu à notification et la période de validité de l’abonnement. |

### Dépendances







### Propriété intellectuelle

Certaines ressources sémantiques de ce guide sont protégées par des droits de propriété intellectuelle couverte par les déclarations ci-dessous. L’utilisation de ces ressources est soumise à l’acceptation et au respect des conditions précisées dans la licence d’utilisation de chacune d’entre elle.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.0.2/CodeSystem-ISO3166Part1.html): [NDE](index.md), [NdE_CommunicationRequest_EventType](SearchParameter-NdE-CommunicationRequest-EventType.md)... Show 16 more, [NdE_Declarant](StructureDefinition-declarant.md), [NdE_Emetteur](CapabilityStatement-NdE-Emetteur.md), [NdE_EventDeclarationNdE](StructureDefinition-nde-eventdeclaration.md), [NdE_EventEmissionTime](StructureDefinition-event-emission-time.md), [NdE_EventTime](StructureDefinition-event-time.md), [NdE_EventType](StructureDefinition-event-type.md), [NdE_GestionnaireDAbonnements](CapabilityStatement-NdE-GestionnaireDAbonnements.md), [NdE_GestionnaireDeNotifications](CapabilityStatement-NdE-GestionnaireDeNotifications.md), [NdE_NotificationRequestNdE](StructureDefinition-nde-notificationrequest.md), [NdE_RecipientEndpoint](StructureDefinition-recipient-endpoint.md), [NdE_Souscripteur](CapabilityStatement-NdE-Souscripteur.md), [NdE_Start](StructureDefinition-start.md), [NdE_Subject](StructureDefinition-subject.md), [NdE_Subscriber](StructureDefinition-subscriber.md), [NdE_SubscriptionDate](StructureDefinition-subscription-date.md) and [NdE_SubscriptionNdE](StructureDefinition-nde-subscription.md)


